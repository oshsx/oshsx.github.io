
$(window).load(function() {
    grayscale($('img.gray'));
});

function init_google_map(map_id) {
    
    var info_window;

    // centruojam zemelapius pagal sias kordinates
    var latlng = [];
    
    latlng['kaunas'] = new google.maps.LatLng(54.92435,23.981471);
    latlng['plunge'] = new google.maps.LatLng(55.917084,21.804734);
    latlng['europa'] = new google.maps.LatLng(51.228426,3.219715);
	
    latlng['praha'] = new google.maps.LatLng(50.061653,14.374877);
    latlng['poland'] = new google.maps.LatLng(54.111522,22.930788);
	
    latlng['lt'] = new google.maps.LatLng(54.92435,23.981471);
    latlng['lv'] = new google.maps.LatLng(56.965132,24.027303);
    latlng['ee'] = new google.maps.LatLng(59.465056,24.712139);
	
    latlng['west_eu'] = new google.maps.LatLng(51.228426,3.219715);
    latlng['west_de'] = new google.maps.LatLng(50.90552,6.93501);
    latlng['west_it'] = new google.maps.LatLng(42.610777,12.209832);
    latlng['west_esp'] = new google.maps.LatLng(40.572376, -3.603805);
	
    latlng['east_soveck'] = new google.maps.LatLng(55.066667,21.883333);
    latlng['east_moscow'] = new google.maps.LatLng(55.720676,37.774526);
    latlng['east_sankt'] = new google.maps.LatLng(59.970586,30.345614);
    latlng['east_ukr'] = new google.maps.LatLng(50.476401,30.487038);
    latlng['east_kz'] = new google.maps.LatLng(43.255058,76.912628);
	
	
    latlng['fact_plunge'] = new google.maps.LatLng(55.917084,21.804734);
    latlng['fact_plunge_senam'] = new google.maps.LatLng(55.912318,21.846266);
    latlng['fact_plunge_salom'] = new google.maps.LatLng(55.910467,21.863057);
    latlng['fact_ee'] = new google.maps.LatLng(59.465056,24.712139);
    latlng['fact_ru'] = new google.maps.LatLng(55.066667,21.883333);
    latlng['fact_spain'] = new google.maps.LatLng(43.43962,-3.863976);


    var myOptions = {
        zoom: 14,
        center: latlng[map_id],
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    
    var map = new google.maps.Map(document.getElementById("google_map"), myOptions);
    
    var markers = [];
    
    if(map_id == 'kaunas') {
        markers.push([new google.maps.LatLng(54.92435,23.981471), $("#kaunas_info_1").html()]);

    }
	
    if(map_id == 'plunge') {
        markers.push([new google.maps.LatLng(55.917084,21.804734), $("#plunge_info_1").html()]);
    }
	
    if(map_id == 'europa') {
        markers.push([new google.maps.LatLng(51.228426,3.219715), $("#europa_info_1").html()]);
 
    }
	
    if(map_id == 'praha') {
        markers.push([new google.maps.LatLng(50.061653,14.374877), $("#praha_info_2").html()]);
 
    }
	
    if(map_id == 'poland') {
        markers.push([new google.maps.LatLng(54.111522,22.930788), $("#poland_info_2").html()]);
 
    }
	
    if(map_id == 'lt') {
        markers.push([new google.maps.LatLng(54.92435,23.981471), $("#lt_info_3").html()]);
 
    }
	
    if(map_id == 'lv') {
        markers.push([new google.maps.LatLng(56.965132,24.027303), $("#lv_info_3").html()]);
 
    }
	
    if(map_id == 'ee') {
        markers.push([new google.maps.LatLng(59.465056,24.712139), $("#ee_info_3").html()]);
 
    }
	
    if(map_id == 'west_eu') {
        markers.push([new google.maps.LatLng(51.228426,3.219715), $("#west_eu_info_4").html()]);
 
    }
	
    if(map_id == 'west_de') {
        markers.push([new google.maps.LatLng(50.90552,6.93501), $("#west_de_info_4").html()]);
 
    }
	
    if(map_id == 'west_it') {
        markers.push([new google.maps.LatLng(42.610777,12.209832), $("#west_it_info_4").html()]);
 
    }
	
	
    if(map_id == 'west_esp') {
        markers.push([new google.maps.LatLng(40.572376, -3.603805), $("#west_esp_info_4").html()]);
 
    }
	

	
    if(map_id == 'east_soveck') {
        markers.push([new google.maps.LatLng(55.066667,21.883333), $("#east_soveck_info_5").html()]);
 
    }
	
    if(map_id == 'east_moscow') {
        markers.push([new google.maps.LatLng(55.720676,37.774526), $("#east_moscow_info_5").html()]);
 
    }
	
    if(map_id == 'east_sankt') {
        markers.push([new google.maps.LatLng(59.970586,30.345614), $("#east_sankt_info_5").html()]);
 
    }
		
    if(map_id == 'east_ukr') {
        markers.push([new google.maps.LatLng(50.476401,30.487038), $("#east_ukr_info_5").html()]);
 
    }
	
    if(map_id == 'east_kz') {
        markers.push([new google.maps.LatLng(43.255058,76.912628), $("#east_kz_info_5").html()]);
 
    }
	

	
    if(map_id == 'fact_plunge') {
        markers.push([new google.maps.LatLng(55.917084,21.804734), $("#fact_plunge_info_6").html()]);
 
    }
	
    if(map_id == 'fact_plunge_senam') {
        markers.push([new google.maps.LatLng(55.912318,21.846266), $("#fact_plunge_senam_info_6").html()]);
 
    }
    if(map_id == 'fact_plunge_salom') {
        markers.push([new google.maps.LatLng(55.910467,21.863057), $("#fact_plunge_salom_info_6").html()]);
 
    }
	
    if(map_id == 'fact_ee') {
        markers.push([new google.maps.LatLng(59.465056,24.712139), $("#fact_ee_info_6").html()]);
 
    }
	
    if(map_id == 'fact_ru') {
        markers.push([new google.maps.LatLng(55.066667,21.883333), $("#fact_ru_info_6").html()]);
 
    }
	
    if(map_id == 'fact_spain') {
        markers.push([new google.maps.LatLng(43.43962,-3.863976), $("#fact_spain_info_6").html()]);
 
    }
	

    /* spausdiname zymeklius */
    $.each(markers, function () {

        var coords = this[0];
        var html   = this[1];

        var new_marker = new google.maps.Marker({
            position: coords,
            map: map
        });

        google.maps.event.addListener(new_marker, 'click', function() {

            if(info_window) {
                info_window.close();
            }

            info_window = new google.maps.InfoWindow({
                content: html
            });

            info_window.open(map, new_marker);

        });
        
    });
}

$(document).ready( function () {

    $(".drop_box > .box").hover(
        function () {            
            grayscale.reset($(this).find('img'));
        },
        function () {
            grayscale($(this).find('img'));
        }
        );
    

    $("#nav > li").hover(
        function () {
            
            var maxHeight = 0;
            $(this).children('div.drop_box').children('div.box').each(function() {
                maxHeight = Math.max(maxHeight, $(this).height());
            }).height(maxHeight);
        },

        function () {}
        );

    /* gallery popup */
    
    var popup = $('#popup');
    
    $('a.map').click(function () {
        
        popup.children('a.prev').remove();
        popup.children('a.next').remove();
        popup.children('img').remove();
        
        popup.children('#google_map').remove();
        popup.append('<div id="google_map"></div>');

        popup.center();

        map_id = $(this).attr('rel');

        $.dimIn({}, function () {
            
            popup.fadeIn(400);
            init_google_map(map_id);

        }, function () {
            popup.fadeOut(400);
            $.dimOut();
        });

        return false;
    });

    popup.children('a.prev').click(function () {
        
        curr_item = $('div.gallery > a.act').prev();
        
        if(!curr_item.prev('a').length) {
            $(this).hide();
        }
        
        if(curr_item.length) {
            show_popup(curr_item);
            popup.children('a.next').show();
        }

        return false;
    });
    
    popup.children('a.next').click(function () {

        curr_item = $('div.gallery > a.act').next();
        
        if(!curr_item.next('a').length) {
            $(this).hide();
        }

        if(curr_item.length) {
            show_popup(curr_item);
            popup.children('a.prev').show();
        }

        return false;
    });

    function show_popup(thumb) {
        
        if(!thumb.next('a').length) {
            popup.children('a.next').hide();
        }
        
        if(!thumb.prev('a').length) {
            popup.children('a.prev').hide();
        }
        
        var img = new Image();
        
        $(img).load(function () { // once the image has loaded, execute this code

            popup.children('img').remove();
            
            // pridedame nauja uzkrauta img
            popup.append(this);

            popup.center();

            $.dimIn({}, function () {
                
                popup.fadeIn(400);
                
            }, function () {
                popup.fadeOut(400);
                $.dimOut();
            });
        })
        .attr('src', thumb.attr('href')); // *finally*, set the src attribute
        
        $('div.gallery > a').removeClass('act');
        thumb.addClass('act');        
    }
    
    $('div.gallery > a').click(function () {
        show_popup($(this));
        return false;
    });
    
    $('#sertificates a.logo').click(function () {
        if($(this).attr('class') == 'logo file') {
            $(this).attr('target', '_blank');
            return true;
        }
        return false;
    });
    
    $('#sertificates a.photo').click(function () {
        show_popup($(this));
        return false;
    });
    
    $('#popup .close').click(function () {
        popup.fadeOut(400);
        $.dimOut();
        return false;
    });
    
    /* LOGO SLIDER */
    
    var logo_slider = $('#logo_slider').bxSlider({
        displaySlideQty: 5,
        moveSlideQty: 1,
        controls: false,
        pause: 4800,
        auto: true
    });
        
    $('#logo_slider_prev').click(function() {
        logo_slider.goToPreviousSlide();
        return false;
    });
    
    $('#logo_slider_next').click(function() {
        logo_slider.goToNextSlide();
        return false;
    });    
    
    /* QUALITY SLIDER */

    var quality_slider = $('#quality_slider').bxSlider({
        displaySlideQty: 2,
        moveSlideQty: 1,
        controls: false,
        pause: 4800,
        auto: true
    });
        
    $('#quality_slider_prev').click(function() {
        quality_slider.goToPreviousSlide();
        return false;
    });
    
    $('#quality_slider_next').click(function() {
        quality_slider.goToNextSlide();
        return false;
    });
    
    /* TOP SLIDER */

    var top_slider = $('#top_home_out').bxSlider({
        displaySlideQty: 1,
        moveSlideQty: 1,
        controls: false,
        pause: 4800,
        auto: true,
        wrapperClass: 'top_wrapper',
        onBeforeSlide: function(currentSlide) {
            
            thumb = $($('#slide_nav li a').get(currentSlide));
            // remove all active classes
            $('#slide_nav li a').removeClass('act');
            // assisgn "pager-active" to clicked thumb
            thumb.addClass('act');
        }
    });
    
    $('#slide_nav li a').click(function(){
        var thumbIndex = $('#slide_nav li a').index(this);
        // call the "goToSlide" public function
        top_slider.goToSlide(thumbIndex);
        return false;
    });
    
    $(window).resize(function () {
        top_slider.resizeShow();
    });

});






jQuery.extend({
    slide: function($container, child_element_no, callback) {
        var $slider = $container.children(":first");
        var new_offset = $slider.children(':eq('+child_element_no+')').offset().left - $container.offset().left - ($slider.offset().left - $container.offset().left);
        $slider.animate( {
            left: -1 * new_offset
        }, 600, 'easeOutQuad', callback);
        return this;
    },
    slide_page: function($container, page_no, size, callback) {
        if (typeof(size) == 'undefined') {
            size = parseInt($container.parent().css('width').match(/\d+/));
        }
        var new_offset = size * page_no;
        $container.animate( {
            left: -1 * new_offset
        }, 600, 'easeOutQuad', callback);
        return this;
    },
    imgLoad: function(src, loaded_callback) {
        var img = new Image();
        $(img).load( function () {
            loaded_callback(img);
        });
        img.src = src;
        return this;
    },
    dimIn: function (user_css, callback, on_click) {
        $dim = $("#dim");
        if ($dim.length == 0) {
            $dim = $("<div />").attr('id', 'dim').css(
            {
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: $(document).height(),
                zIndex: 1000,
                background: '#333',
                opacity: .7
            });
            $('body').append($dim);
        }
        
        window.dim_height = $(document).height();
        window.dim_height_int = setInterval(function () {
            if (window.dim_height != $(document).height()) {
                window.dim_height = $(document).height();
                $dim.css('height', window.dim_height);
            }
        }, 100);
        
        if (on_click != undefined) {
            $dim.click(on_click);
        }
        if ($dim.data('act') == true) return false;
        if (user_css != undefined) {
            $dim.css(user_css);
        }
        return $dim.data('act', true).fadeIn(400, callback);
    },
    dimOut: function (callback) {
        $dim = $("#dim").unbind('click');
        if ($dim.data('act') == true) {
            $dim.fadeOut(400, callback).data('act', false);
        }
        clearInterval(window.dim_height_int);
    },
    alert: function (message) {
        $.dimIn({}, null, function () {
            window.alert_box.fadeOut();
            $.dimOut();
        });
        if (window.alert_box == undefined) {
            window.alert_box = $('<div style="width: 400px; z-index:99999999; display: none; cursor: pointer; position: absolute; padding: 10px; background: #fff; box-shadow: 0 0 5px #666; -moz-box-shadow: 0 0 5px #666; -webkit-box-shadow: 0 0 5px #666;" />').appendTo('body').click( function () {
                $(this).fadeOut();
                $.dimOut();
            } );
        }
        window.alert_box.html('<p style="display: block; text-align: left;">'+message+'</p>').center().fadeIn();
    }
});

jQuery.fn.extend({
    defaultText: function () {
        var $t = this;
        if ($t.length > 1) {
            $t.each(function () {
                $(this).defaultText();
            })
            return $t;
        }
        $t.bind('focus', function() {
            if ($t.data('default-text') == undefined) {
                $t.data('default-text', $t.val());
            }
            if ($t.val() == $t.data('default-text')) {
                $t.val('');
            }
        });
        $t.blur(function () {
            if (($t.val() == '') && ($t.data('default-text') != undefined)) {
                $t.val($t.data('default-text'));
            }
        });
        return $t;
    },
    center: function () {
        
        // CSS fix, display:none width and height
        //this.css({visibility:'visible', display:'block'});
        
        this.css( {
            position: 'absolute',
            top: $(document).scrollTop() + (Math.ceil($(window).height()) - this.outerHeight()) / 2,
            left: '50%',
            marginLeft: -1 * Math.ceil(this.outerWidth() / 2)
        } );
        
        return this;
    },
    fadeOver: function (speed, callback, css, attr) {
        var $t = this;
        c = $t.clone();
        c.css( {
            position: 'absolute',
            width: $t.width(),
            height: $t.height(),
            display: 'none',
            zIndex: 2
        } );
        if (css != undefined) {
            c.css(css);
        }
        if (attr != undefined) {
            c.attr(attr);
        }
        $tp = $t.parent(); // container
        $tp.css( {
            width: $tp.width(),
            height: $tp.height()
        } );

        c.insertBefore($t).fadeTo(speed, 1, function () {
            c.next().remove();
            c.css( {
                position: 'relative', 
                zIndex: 1
            } );
            if (typeof(callback) == 'function') callback();
        });
        return $t;
    }
});